from django.http.response import HttpResponse
from django.shortcuts import render, HttpResponse, redirect

locations = {
    "Bellevue, WA",
    "Boise, ID",
    "Chicago, IL",
    "Dallas, TX",
    "Los Angeles, CA",
    "Silicon Valley, CA",
}
languages = {
    "Python",
    "JavaScript",
    "Java",
    "C#",
    "Ruby",
}
# place views below!
def index(request):
    context = {
        "language": languages,
        "location": locations,
    }
    return render(request, "index.html", context)

# def input(request):
#     return redirect('/result')

def result(request):
    request.session['result'] = {
    'name': request.POST['name'],
    'location': request.POST['location'],
    'language': request.POST['language'],
    'comment': request.POST['comment'],
    }
    context = {
        "result": request.session['result']
    }
    return render(request, "info.html", context)

